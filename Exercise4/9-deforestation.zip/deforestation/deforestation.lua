
CELL_AREA = 25 * 25 -- km2
DEMAND = 25000 -- yearly demand
LIMIT = 30 -- max deforestation not allocated in each year

deforLeg = Legend{
	slices = 10,
	colorBar = {
		{value = 0, color = "green"},
		{value = 1, color = "red"}
	}
}

amazonia = CellularSpace{
	database = "c:\\amazonia.mdb",
	theme = "AmzCells"
}		

amazonia:createNeighborhood()

forEachCell(amazonia, function(cell)
	cell.defor = cell.defor2001
end)

obs = Observer{
	subject = amazonia,
	attributes = {"defor"},
	legends = {deforLeg}
}

amazonia:notify()

totalDefor = function(cs)
	total = 0
	forEachCell(cs, function(cell)
		total = total + cell.defor
	end)
	print(total)
end

calculatePotNeighborhood = function(cs)
	local total_pot = 0

	forEachCell(cs, function(cell)
		cell.pot = 0
		local countNeigh = 0

		if cell.defor < 1.0 then
			forEachNeighbor(cell, function(cell, neigh)
				cell.pot = cell.pot + neigh.defor
				countNeigh = countNeigh + 1
			end)
			if cell.pot > 0 then
				cell.pot = cell.pot / countNeigh
				total_pot = total_pot + cell.pot
			end
		end
	end)
	return total_pot
end

calculatePotRegression = function(cs)
	local total_pot = 0

	forEachCell(cs, function(cell)
		cell.pot = 0

		if cell.defor < 1.0 then
			expected =  - 0.450 * math.log(cell.distRoads)
						+ 0.260 * 1 / cell.distPorts
						- 0.140 * cell.protectedArea
						+ 5.313

			if expected > cell.defor then
				cell.pot = expected - cell.defor
				total_pot = total_pot + cell.pot
			end
		end
	end)
	return total_pot
end

calculatePotMixed = function(cs)
	local total_pot = 0

	forEachCell(cs, function(cell)
		cell.pot = 0
		cell.ave_neigh = 0

		countNeigh = 0
		forEachNeighbor(cell, function(cell, neigh)
			if cell.defor < 1.0 then
				cell.ave_neigh = cell.ave_neigh + neigh.defor
				countNeigh = countNeigh + 1
			end
		end)
	
		if cell.defor < 1.0 then
			cell.ave_neigh = cell.ave_neigh / countNeigh
		end

		if cell.defor < 1.0 then
			expected =    0.7300 * cell.ave_neigh
						- 0.1500 * math.log(cell.distRoads)
						+ 0.0500 * 1 / cell.distPorts
						- 0.0700 * cell.protectedArea
						+ 2.7734

			if expected > cell.defor then
				cell.pot = expected - cell.defor
				total_pot = total_pot + cell.pot
			end
		end
	end)
	return total_pot
end

deforest = function(cs, total_pot)
	local total_demand = DEMAND
	while (total_demand > LIMIT) do
		forEachCell(cs, function(cell)
			newarea = (cell.pot / total_pot) * total_demand
			cell.defor = cell.defor + newarea / CELL_AREA
			if cell.defor >= 1 then
				total_pot = total_pot - cell.pot
				cell.pot = 0
				excess = (cell.defor - 1) * CELL_AREA
				cell.defor = 1
			else
				excess = 0
			end
			total_demand = total_demand - (newarea - excess)
		end)
	end
end

calculatePot = {calculatePotNeighborhood, calculatePotRegression, calculatePotMixed}
currentPot = calculatePot[3]

hasPotential = function(cell1)
	return cell1.pot > 0
end

greaterPotential = function(cell1, cell2)
	return cell1.pot > cell2.pot
end

traj = Trajectory{
	target = amazonia,
	select = hasPotential,
	sort = greaterPotential,
	build = false
}

totalDefor(amazonia)

t = Timer{
	Event{time = 2002, action = function(event)
		print("Time:", event:getTime()) io.flush()
		local total_pot = currentPot(amazonia)

		traj:rebuild()
		deforest(traj, total_pot)
		totalDefor(amazonia)
		amazonia:notify()
	end}
}

t:execute(2011)

