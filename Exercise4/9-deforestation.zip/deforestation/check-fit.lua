dofile("goodness-of-fit.lua")

amz = CellularSpace {
	database = "c:\\prodes.mdb",
	theme = "AmzCells"
}

prodes = CellularSpace{
 	database =  "c:\\prodes.mdb",
	theme = "AmzCells"
}

gof = GoodnessOfFit{
	cs1 = prodes, 
	attr1 = "prodes2007",
	cs2 = prodes,
	attr2 = "prodes2004",
	demand = 13601.1413
}

gof:chart()
print("Goodness of fit: "..gof:fit())

