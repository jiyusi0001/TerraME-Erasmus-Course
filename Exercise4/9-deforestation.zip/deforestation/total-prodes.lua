-- Compute the total yearly deforestation from PRODES

prodes = CellularSpace {
	database = "c:\\Prodes.mdb",
	theme = "AmzCells"
}

for i = 2002, 2011 do
	att = "prodes"..i
	tot_prodes = 0
	forEachCell(prodes, function(cell)
		tot_prodes = tot_prodes + cell[att] * 25 * 25
	end)
	print(att..": "..tot_prodes)
end

