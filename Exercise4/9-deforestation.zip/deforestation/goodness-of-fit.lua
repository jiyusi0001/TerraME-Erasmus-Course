-- Goodness-of-fit for Land Change Models
-- Luiz Veras and Pedro Andrade
-- 2013-06-25

GoodnessOfFit_ = {
	resoMax = 0,
	maxColumn = 0,
	ano = 0,
	posNextData = 0,
	arqTotalSets = 0,
	fit = function(self)
		ajustesMultiResolucao = self.tableOfFits
		local k = 0.1 -- peso dado a janelas de certo tamanho
		local p = 0
		local c = 1
		local ajusteTotal

		for k = 0, 1, 0.1 do
			local somaPonderada = 0
			local somaPesos = 0
			
			for i, janela in ipairs(ajustesMultiResolucao) do
				somaPonderada = somaPonderada + janela.fitWindow*math.exp((-1)*k*(2^janela.sizeWindow))
				somaPesos = somaPesos + math.exp((-1)*k*(2^janela.sizeWindow))
			end	
		
			ajusteTotal = somaPonderada/somaPesos
		end

		return ajusteTotal
	end,
	WindowfitCalculator = function (cs1, attr1,cs2, attr2, size_window, cellPosition)
		local differenceSum = 0
		local visited_cells = 0
		local differenceSum = 0
		local somaValorRef = 0
		local difference = 0

		local somaCell1 = 0
		local somaCell2 = 0

		--calculo do erro em uma das janelas de tamanho size_window^2
		for i = 0 , size_window , 1 do		
			for j = 0 , size_window , 1 do
				if cellPosition.x + j < cs1.xdim and cellPosition.y + i < cs1.xdim then
					idx = coord2index(cellPosition.x + j, cellPosition.y + i, cs1.xdim)							
					cell_1 = cs1.cells[idx]		
					--uma celula ser� nula ou seu atributo nulo se a janela de amostragem
					--extrapolar a dimens�o do mapa que realmente cont�m os dados para compara��o			
					if cell_1~=nil and cell_1[attr1] ~= nil then -- ent�o cell_2 tamb�m ser�				
						cell_2 = cs2.cells[idx]
						somaCell1 = somaCell1 + tonumber(cell_1[attr1])
						somaCell2 = somaCell2 + tonumber(cell_2[attr2])

						visited_cells = visited_cells + 2
					end
				end
			end		
		end

		if visited_cells == 0 then
			return 0,0,0,0
 		else
 			differenceSum = math.abs(somaCell1 - somaCell2)
			return differenceSum/2, visited_cells/(2*((size_window+1)^2)), 1, somaValorRef/visited_cells
		end
	end,
	-- fun��o que faz transcorrer a janela de amostragem pelo espa�o celular
	windowRun = function(self, cs1, attr1, cs2, attr2, size_window, reso_max)
		local i, j
		local cell_pointer, horizontal_limit, vertical_limit
		local fits_sum = 0
		local amount_window = 0
		local fit_add
		local janelas = 0
		local add_window

		local resoStartI = 0
		local resoMaxI = reso_max

		local resoStartJ = 0
		local resoMaxJ = reso_max

		local fitTable = {}

		local t = 1

		for i = resoStartI, resoMaxI, size_window do
			for j = resoStartJ, resoMaxJ, size_window do
				cell_pointer = {x = j, y = i}
				s, w, add_window, ref = self.WindowfitCalculator(cs1, attr1, cs2, attr2, size_window-1, cell_pointer)

				if add_window > 0 then
					amount_window = amount_window + add_window			
					fitTable[t] = {set = s, weight = w, referenceMap = ref}			
					t = t + 1
				end
							
				vertical_limit = j + size_window			
	
				if vertical_limit > resoMaxJ then			
					break
				end
			end

			horizontal_limit = i + size_window

			if horizontal_limit > resoMaxI then						
				local fits = 0
				local fitsWeighted = 0
				local weight = 0
				local sumReferenceMap = 0

				for i, x in ipairs(fitTable) do
					fits = fits + x.set
					weight = weight + x.weight
				end
			
				return size_window, fits/self.demand
			end
		end
	end,
	chart = function(self)
		tableOfFits = self.tableOfFits
		local cell_fit = Cell{size = 0 , fit = 0}
	
		Observer{
		  	subject = cell_fit,
		    type = "chart",
			attributes = {"fit"},
			title = "Error Curve",
			xLabel = "Window Size",
			yLabel = "Error"
		}

		for i, window in ipairs(tableOfFits) do
			cell_fit.size = window.sizeWindow
			cell_fit.fit = window.fitWindow
			cell_fit:notify(i)	
		end
	end,
	selectBiggestAxisCell = function(cs)
		local BiggestCell = {x = 0, y = 0}

		forEachCell(cs, function(cell)
			if BiggestCell.x < cell.x then
				BiggestCell.x = cell.x
			end
			if BiggestCell.y < cell.y then
				BiggestCell.y = cell.y
			end
		 end)

		local Dimension

		if BiggestCell.x == BiggestCell.y then
			Dimension = BiggestCell.x 
		elseif BiggestCell.x > BiggestCell.y then
			Dimension = BiggestCell.x
		else 
			Dimension = BiggestCell.y
		end
		return Dimension, BiggestCell.x
	end,
	irregularDB2RegularDB = function(cs, dimCs, attr)
		newCs = CellularSpace{xdim = dimCs + 1}
	
		forEachCell(newCs, function(cell)
			cell2copy = cs:getCell(Coord{x = cell.x, y = cell.y})
					
			if cell2copy then
				cell[attr] = cell2copy[attr]
			end					
		end)			
		return newCs
	end
}

local metaTableGoodnessOfFit_ = {__index = GoodnessOfFit_}

function GoodnessOfFit(attrTab)
	if attrTab.cs1:size() ~= attrTab.cs2:size() then
		error("Error: Data bases with diferrent sizes.", 2)
	end

	setmetatable(attrTab, metaTableGoodnessOfFit_)

	attrTab.resoMax = attrTab.selectBiggestAxisCell(attrTab.cs1)

	attrTab.cs1 = attrTab.irregularDB2RegularDB(attrTab.cs1, attrTab.resoMax, attrTab.attr1)
	attrTab.cs2 = attrTab.irregularDB2RegularDB(attrTab.cs2, attrTab.resoMax, attrTab.attr2)	
	
	attrTab.tableOfFits = {}
	local size_window
	local size, fit
	temp = 0
	
	local i = 1
	for size_window = 0, attrTab.resoMax , 1 do		
		size, fit = attrTab:windowRun(attrTab.cs1, attrTab.attr1, attrTab.cs2, attrTab.attr2, size_window+1, attrTab.resoMax)
		local sizeLog = math.log(size)/math.log(2)
		
		if sizeLog%1 == 0 then 
			attrTab.tableOfFits[i] = {sizeWindow = sizeLog, fitWindow = 100*fit}
			i = 1 + i
		end		
	end
	return attrTab
end

