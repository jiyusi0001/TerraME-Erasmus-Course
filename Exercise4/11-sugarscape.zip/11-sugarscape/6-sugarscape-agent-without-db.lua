
cs = CellularSpace {
	xdim = 50,
	ydim = 50
}

cs:createNeighborhood{strategy = "vonneumann"}

forEachCell(cs, function(cell)
	cell.maxSugar = 0
	cell.sugar = 0
end)

cs:getCell(Coord{x = 11, y = 35}).maxSugar = 4
cs:getCell(Coord{x = 36, y = 10}).maxSugar = 4

for i = 1, 5 do
	cs:synchronize()
	forEachCell(cs, function(cell)
		forEachNeighbor(cell, function(cell, neighbor)
			if neighbor.past.maxSugar == 4 then
				cell.maxSugar = 4
			end
		end)
	end)
end

for i = 1, 6 do
	cs:synchronize()
	forEachCell(cs, function(cell)
		forEachNeighbor(cell, function(cell, neighbor)
			if neighbor.past.maxSugar >= 3 and cell.maxSugar == 0 then
				cell.maxSugar = 3
			end
		end)
	end)
end

for i = 1, 7 do
	cs:synchronize()
	forEachCell(cs, function(cell)
		forEachNeighbor(cell, function(cell, neighbor)
			if neighbor.past.maxSugar >= 2 and cell.maxSugar == 0 then
				cell.maxSugar = 2
			end
		end)
	end)
end

for i = 1, 10 do
	cs:synchronize()
	forEachCell(cs, function(cell)
		forEachNeighbor(cell, function(cell, neighbor)
			if neighbor.past.maxSugar >= 1 and cell.maxSugar == 0 then
				cell.maxSugar = 1
			end
		end)
	end)
end

leg = Legend {
	slices = 5,
	colorBar = {
		{value = 0, color = "white"},
		{value = 4, color = "red"}
	}
}

Observer {
	subject = cs,
	attributes = {"sugar"},
	legends = {leg}
}

sugarAgent = Agent{
	wealth = 0,
	execute = function(self)
		candidate = self:getCell():getNeighborhood():sample()
		if candidate.sugar >= self:getCell().sugar then
			self:move(candidate)
		end

		self.wealth = self.wealth + self:getCell().sugar
		self:getCell().sugar = 0
	end
}

e = Environment{cs, sugarAgent}

e:createPlacement{strategy = "random", max = 1}

growSugar = function()
	forEachCell(cs, function(cell)
		if cell.sugar < cell.maxSugar then
			cell.sugar = cell.sugar + 1
		end
	end)
end

t = Timer{
	Event{action = growSugar},
	Event{action = sugarAgent},
	Event{action = cs}
}

t:execute(1000)

