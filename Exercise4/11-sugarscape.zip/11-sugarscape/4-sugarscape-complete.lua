
cs = CellularSpace {
	database = "c:\\sugarscape.mdb",
	theme = "sugarscape",
	select = {"maxSugar", "sugar"}
}

cs:createNeighborhood{strategy = "vonneumann"}

leg = Legend {
	slices = 5,
	colorBar = {
		{value = 0, color = "white"},
		{value = 4, color = "red"}
	}
}

Observer {
	subject = cs,
	attributes = {"sugar"},
	legends = {leg}
}

sugarAgent = Agent{
	age = 0,
	init = function(self)
		self.wealth = math.random(5, 25)
		self.metabolism = math.random(1, 4)
		self.maxAge = math.random(60, 100)
	end,
	execute = function(self)
		bestOptions = {self:getCell()}
		forEachNeighbor(self:getCell(), function(cell, neighbor)
			if neighbor.sugar > bestOptions[1].sugar then
				bestOptions = {neighbor}
			elseif neighbor.sugar == bestOptions[1].sugar then
				bestOptions[table.getn(bestOptions)+1] = neighbor
			end
		end)

		bestOption = bestOptions[math.random(table.getn(bestOptions))]
		self:move(bestOption)

		self.age = self.age + 1
		self.wealth = self.wealth - self.metabolism + self:getCell().sugar
		self:getCell().sugar = 0

		if self.age > self.maxAge or self.wealth <= 0 then
			son = self:reproduce()
			son:enter(cs:sample())
			self:die()
		end
	end
}

soc = Society{
	instance = sugarAgent,
	quantity = 50
}

cell = Cell{
	wealth = 0,
	age = 0
}

updateCell = function()
	cell.wealth = 0
	cell.age = 0
	forEachAgent(soc, function(agent)
		cell.age = cell.age + agent.age
		cell.wealth = cell.wealth + agent.wealth
	end)
	cell.age = cell.age / soc:size()
	cell.wealth = cell.wealth / soc:size()
end

Observer{
	subject = cell,
	type = "chart",
	attributes = {"age", "wealth"},
	curveLabels = {"age", "wealth"}
}

e = Environment{cs, soc}

e:createPlacement{strategy = "random", max = 1}

growSugar = function()
	forEachCell(cs, function(cell)
		if cell.sugar < cell.maxSugar then
			cell.sugar = cell.sugar + 1
		end
	end)
end

t = Timer{
	Event{action = growSugar},
	Event{action = soc},
	Event{action = updateCell},
	Event{action = cs},
	Event{action = cell}
}

t:execute(1000)

