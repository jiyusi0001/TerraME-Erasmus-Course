
cs = CellularSpace {
	database = "c:\\sugarscape.mdb",
	theme = "sugarscape",
	select = {"maxSugar", "sugar"}
}

cs:createNeighborhood{strategy = "vonneumann"}

leg = Legend {
	slices = 5,
	colorBar = {
		{value = 0, color = "white"},
		{value = 4, color = "red"}
	}
}

Observer {
	subject = cs,
	attributes = {"sugar"},
	legends = {leg}
}

growSugar = function()
	forEachCell(cs, function(cell)
		if cell.sugar < cell.maxSugar then
			cell.sugar = cell.sugar + 1
		end
	end)
end

consume = function()
	cs:sample().sugar = 0
	cs:sample().sugar = 0
	cs:sample().sugar = 0
	cs:sample().sugar = 0
	cs:sample().sugar = 0
	cs:sample().sugar = 0
	cs:sample().sugar = 0
	cs:sample().sugar = 0
end

t = Timer{
	Event{action = growSugar},
	Event{action = consume},
	Event{action = cs}
}

t:execute(1000)

