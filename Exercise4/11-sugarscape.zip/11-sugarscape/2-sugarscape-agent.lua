
cs = CellularSpace {
	database = "c:\\sugarscape.mdb",
	theme = "sugarscape",
	select = {"maxSugar", "sugar"}
}

cs:createNeighborhood{strategy = "vonneumann"}

leg = Legend {
	slices = 5,
	colorBar = {
		{value = 0, color = "white"},
		{value = 4, color = "red"}
	}
}

Observer {
	subject = cs,
	attributes = {"sugar"},
	legends = {leg}
}

sugarAgent = Agent{
	wealth = 0,
	execute = function(self)
		candidate = self:getCell():getNeighborhood():sample()
		if candidate.sugar >= self:getCell().sugar then
			self:move(candidate)
		end

		self.wealth = self.wealth + self:getCell().sugar
		self:getCell().sugar = 0
	end
}

e = Environment{cs, sugarAgent}

e:createPlacement{strategy = "random", max = 1}

growSugar = function()
	forEachCell(cs, function(cell)
		if cell.sugar < cell.maxSugar then
			cell.sugar = cell.sugar + 1
		end
	end)
end

t = Timer{
	Event{action = growSugar},
	Event{action = sugarAgent},
	Event{action = cs}
}

t:execute(1000)

